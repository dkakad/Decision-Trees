% 24-787 Artificial Intelligence and Machine Learning for Engg Design
% Assignment 1 - Question 4
% This script generates random sample points of a Gaussian Distribution and
% then computes the mean and covariance of the new points
% Finally, this script tries to classify test points on the basis of which 
% Gaussian Distribution class the test points belong to
% 
% @Author - Deepak Kakad
% Andrew ID - dkakad

clc;
clear all;
close all;

% Number of training points. More the points higher the accuracy of the 
% results
N = 20; 

mu1 = zeros(3,1);
mu1 = mu1';

v1 = [3,5,2];
sig1 = diag(v1);

mu2 = [1 , 5 , -3];
sig2 = [1,0,0;0,4,1;0,1,6];

mu3 = mu1;
sig3 = 10*eye(3);

% Generate random points based on mu and sigma
class1 = getRandom(mu1 , sig1 , N);
class2 = getRandom(mu2 , sig2 , N);
class3 = getRandom(mu3 , sig3 , N);

drawPlot(class1);
hold on;
drawPlot(class2);
hold on;
drawPlot(class3);

% Calculate mean of the new random points
mu1 = getMean(class1);
mu2 = getMean(class2);
mu3 = getMean(class3);

% Calculate covariance of the new random points
cov1 = getCov(class1);
cov2 = getCov(class2);
cov3 = getCov(class3);



disp('mu1 = ');
disp(mu1);

disp('mu2 = ');
disp(mu2);

disp('mu3 = ');
disp(mu3);


disp('cov1 = ');
disp(cov1);

disp('cov2 = ');
disp(cov2);

disp('cov3 = ');
disp(cov3);


% For Validity

% disp(mean(class1));
% disp(mean(class2));
% disp(mean(class3));

% disp(cov(class1));
% disp(cov(class2));
% disp(cov(class3));

% Test points
v1 = [0 , 0 , 0];
v1 = [v1 ; 1 , 6 , -3];
v1 = [v1 ; 0.8 , 3.0 , -1.5];
v1 = [v1 ; 8 , -8 , 8];
v1 = [v1 ; -1 , 1 , -1];
v1 = [v1 ; 0 , 5 , 0];


result = zeros(1 , length(v1));
for i = 1 : length(v1)
    
    % Get the probability of test points on the basis of the mu and sigma
    p1 = getProbDist(v1(i , :) , mu1 , cov1);
    p2 = getProbDist(v1(i , :) , mu2 , cov2);
    p3 = getProbDist(v1(i , :) , mu3 , cov3);
    p = [p1 , p2 , p3];
    max_Prob = max(p);
    
    if(max_Prob == p1)
        result(1 , i) = 1;
    elseif (max_Prob == p2)
        result(1 , i) = 2;
    else
        result(1 , i) = 3;
    end
end



