function drawPlot(class)
scatter3(class(:,1), class(:,2) , class(:,3));