function cov1 =  getCov(class)
mean1 = getMean(class);

sz = size(class);
N = sz(1);
m1 = repmat(mean1 , N , 1);
c1 = class - m1;
cov1 = c1'*c1;
cov1 = cov1./N;