function mean = getMean(class)
sum1 = sum(class);
sz = size(class);
N = sz(1);
mean = sum1./N;