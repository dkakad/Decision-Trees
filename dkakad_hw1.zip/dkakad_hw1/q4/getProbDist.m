function prob = getProbDist(v1 , mu , sigma)
prob = 1 / (((2 * pi)^(3/2)) * ((det(sigma))^0.5));
prob = prob * exp(-0.5 * (v1 - mu) * inv(sigma) * (v1 - mu)');
