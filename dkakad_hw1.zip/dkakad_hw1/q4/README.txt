The main script for this question is named main.m

All the other scripts are supporting fuctions for the main script

The plot of the randomly generated points is generated when you run the main script.
The results of the classification can be found in the variable name 'result' in the main script.

Increase N for a more accurate classification of the test points.
