function class = getRandom(mu , sigma , N)
R1 = chol(sigma);
class = repmat(mu , N , 1) + randn(N , 3)*R1;

