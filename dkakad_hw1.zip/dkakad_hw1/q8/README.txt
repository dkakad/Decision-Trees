Please find the main submission in the script hwkgestures.m

All the other scripts are supporting functions for the main script

The explanation for all the features is given within the following script files:
1) extractAvgTheta
2) extractCentroid
3) extractCentroidRev


Ensure that there is a Test folder which has 50 .txt files. 
Also ensure that the data folder has 3 subfolders Alpha , Beta and Delta.
There should be 11 .txt files in Alpha , 10 in beta and 12 in Delta.

The output will be displayed in the file testresults.txt 