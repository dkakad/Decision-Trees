% 24-787 Artificial Intelligence and Machine Learning for Engg Design
% Assignment 1 - Question 8
% This script performs gesture recognition for single stroke gestures using
% supervised learning with the help of training data.
% 
% @Author - Deepak Kakad
% Andrew ID - dkakad

%% Start of Script
clc;
close all;
clear all;

%% Read the 'alpha' files and learn it's features

sizes = [11 , 10 , 12]; % No of the alpha , beta and delta files

% Preallocate for speed
A = cell(sizes(1));
text2_Alpha{sizes(1)} = [];
feat1_Alpha = zeros(1 , sizes(1));
feat2_Alpha = zeros(1 , sizes(1));
feat3_Alpha = zeros(1 , sizes(1));

for i = 1 : sizes(1)
    text2_Alpha{i} = strcat('data/alpha/t' , num2str(i) , '.txt');
    vec2_Alpha = load(text2_Alpha{i}); % Load the alpha training data

    feat1_Alpha(i) = extractAvgTheta(vec2_Alpha); % Extract feature 1
    feat2_Alpha(i) = extractCentroid(vec2_Alpha); % Extract feature 2
    feat3_Alpha(i) = extractCentroidRev(vec2_Alpha); % Extract feature 3
    
end
feat_Alpha = [feat1_Alpha ; feat2_Alpha ; feat3_Alpha];
feat_Alpha = feat_Alpha';

disp('Feature Vector for first Alpha training file')
disp(feat_Alpha(1 , :));

alpha_Mean = getMean(feat_Alpha); 
alpha_Cov = getCov(feat_Alpha); 

disp('Mean of Features for Alpha ')
disp(alpha_Mean);

disp('Covariance of Features for Alpha ')
disp(alpha_Cov);

% End of Alpha 

%% Read the 'beta' files and learn it's features

B = cell(sizes(2));
text2_Beta{sizes(2)} = [];
feat1_Beta = zeros(1 , sizes(2));
feat2_Beta = zeros(1 , sizes(2));
feat3_Beta = zeros(1 , sizes(2));

for i = 1 : sizes(2)
    text2_Beta{i} = strcat('data/beta/t' , num2str(i) , '.txt');
    vec2_Beta = load(text2_Beta{i});
    
    feat1_Beta(i) = extractAvgTheta(vec2_Beta);
    feat2_Beta(i) = extractCentroid(vec2_Beta);
    feat3_Beta(i) = extractCentroidRev(vec2_Beta);

end

feat_Beta = [feat1_Beta ; feat2_Beta ; feat3_Beta];
feat_Beta = feat_Beta';

disp('Feature Vector for first Beta training file')
disp(feat_Beta(1 , :));

beta_Mean = getMean(feat_Beta);
beta_Cov = getCov(feat_Beta);

disp('Mean of Features for Beta ')
disp(beta_Mean);

disp('Covariance of Features for Beta ')
disp(beta_Cov);

% End of beta

%% Read the 'delta' files and learn it's features

C = cell(sizes(3));
text2_Delta{sizes(1)} = [];
feat1_Delta = zeros(1 , sizes(3));
feat2_Delta = zeros(1 , sizes(3));
feat3_Delta = zeros(1 , sizes(3));

for i = 1 : sizes(3)
    text2_Delta{i} = strcat('data/delta/t' , num2str(i) , '.txt');
    vec2_Delta = load(text2_Delta{i});

    feat1_Delta(i) = extractAvgTheta(vec2_Delta);
    feat2_Delta(i) = extractCentroid(vec2_Delta);
    feat3_Delta(i) = extractCentroidRev(vec2_Delta);

end

feat_Delta = [feat1_Delta ; feat2_Delta ; feat3_Delta];
feat_Delta = feat_Delta';

disp('Feature Vector for first Delta training file')
disp(feat_Delta(1 , :));

delta_Mean = getMean(feat_Delta);
delta_Cov = getCov(feat_Delta);

disp('Mean of Features for Delta ')
disp(delta_Mean);

disp('Covariance of Features for Delta ')
disp(delta_Cov);

% End of delta

%% Deploy the Supervised Learning Algorithm on test cases

fileID = fopen('testresult.txt' , 'w'); % File to write results in

N = 50; % Please change this value based on the number of testing files
D = cell(N);
text1{N} = [];
feat1 = zeros(1 , N);
feat2 = zeros(1 , N);
feat3 = zeros(1 , N);
result = zeros(1 , N);

for i = 1 : N
    text1{i} = strcat('Test/test' , num2str(i) , '.txt');
    vec2 = load(text1{i});

    feat1(i) = extractAvgTheta(vec2); % Extract feature 1 of test
    feat2(i) = extractCentroid(vec2); % Extract feature 2 of tes
    feat3(i) = extractCentroidRev(vec2); % Extract feature 3 of tes
    
    feat = [feat1  ; feat2 ; feat3];
    feat = feat';
    p1 = getProbDist(feat(i , :) , alpha_Mean , alpha_Cov); % Check if alpha
    p2 = getProbDist(feat(i , :) , beta_Mean , beta_Cov); % Check if beta
    p3 = getProbDist(feat(i , :) , delta_Mean , delta_Cov); % Check if delta
    
    p = [p1 , p2 , p3];
    max_Prob = max(p); % Find the max of the 3 probabilities
    
    if(max_Prob == p1)
        result(1 , i) = 1;
    elseif (max_Prob == p2)
        result(1 , i) = 2;
    else
        result(1 , i) = 3;
    end
    
    fprintf(fileID, '%d \n', result(1,i)); % Print the result
end

fclose(fileID); % Close File Descriptor

%% End of script








