% Feature 2 : Angle between the Centroid and First Point
%
% A Function to determine the angle made by the line joining the centroid of
% the bounding box and the first point of the gesture
%
% Feature Explaination: We find the angle made by the line joining the 
% centroid of the Bounding Box of the gesture point cloud and the first
% point of the cloud (start of the stroke) with the Horizontal axis

function feat = extractCentroid(vec2)

% Extract the Bounding Box
xmax = max(vec2(: , 1));
ymax = max(vec2(: , 2));
xmin = min(vec2(: , 1));
ymin = min(vec2(: , 2));

% Centroid of the Bounding Box
cent_X = (xmax + xmin) / 2; 
cent_Y = (ymax + ymin) / 2; 

dx = vec2(1 , 1) - cent_X;
dy = vec2(1 , 2) - cent_Y;

% Feature 2
feat = atan2(dy , dx) + 3.14159;
