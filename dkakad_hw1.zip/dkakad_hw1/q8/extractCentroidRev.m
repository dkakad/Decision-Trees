% Feature 3 : Angle between the Centroid and Last Point
%
% A Function to determine the angle made by the line joining the centroid of
% the bounding box and the last point of the gesture
%
% Feature Explaination: We find the angle made by the line joining the 
% centroid of the Bounding Box of the gesture point cloud and the last
% point of the cloud (end of the stroke) with the Horizontal axis

function feat = extractCentroidRev(vec2)
N = length(vec2);
xmax = max(vec2(: , 1));
ymax = max(vec2(: , 2));
xmin = min(vec2(: , 1));
ymin = min(vec2(: , 2));

cent_X = (xmax + xmin) / 2;
cent_Y = (ymax + ymin) / 2;

dx = vec2(N-1 , 1) - cent_X;
dy = vec2(N-1 , 2) - cent_Y;

feat = atan2(dy , dx) + 3.14159;
