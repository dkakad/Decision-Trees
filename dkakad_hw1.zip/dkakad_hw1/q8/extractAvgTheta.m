% Feature 1 : Avgtheta
%
% A function to determine how rapidly the gesture changes it's curvature
%
% Feature Explaination: We find the angle made by the line joining any 2
% consecutive points of the gesture point cloud and find the angle that it 
% makes with the Horizontal Axis. 
%
% We keep on adding them to a variable theta. Finally we normalize the
% summation of the angles (theta) by dividing it with the total number of
% points minus one

function feat = extractAvgTheta(vec2)
N = length(vec2);
theta = 0;
for i = 1 : N - 1   
    dx = vec2(i+1 , 1) - vec2(i , 1);
    dy = vec2(i+1 , 2) - vec2(i , 2);
    theta = theta + atan2(dy , dx) + 3.14159;
end

% Feature 1
feat = theta / (N-1); 
    
    